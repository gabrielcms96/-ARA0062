<?php
session_start ();

if ( ! isset ($_SESSION ["autenticado"])) 
{
    echo "
    <script>
        window.location.replace ('login.php')
    </script>";
}
?>
<!doctype html>
<html>
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <style>
        h3{color:white;}
        h3{background-color:#1181EF;}
        h3{font-family:"Aclonica", sans-serif;}
        h1{font-family:"Aclonica", sans-serif;}
        h4{font-size:30px;}
        p {font-size:20px;}
    </style>
    
    <link href="https://fonts.googleapis.com/css2?family=Aclonica&display=swap" rel="stylesheet">
    <title>Alteração de Blog</title>
  </head>
  <body>
    <div class="container">
        <div class="col-sm">
            <center><h1>Edição de Blog</h1></center>
            <hr>
            <a href="../blog.php"> < Voltar</a>
            <br><br>
            
            <?php
            
                include_once("../servico/Bd.php");
                $bd = new Bd();
                $id = $_GET['id'];
                $sql = "select * from blog where id='$id'";
                
                foreach ($bd->query($sql) as $row) {
                    $id = $row['id'];
                    $titulo = $row['titulo'];
                    $corpo = $row['corpo'];
                }
            
            ?>
        
            <form action="salvarBlog.php" method="post">
              <div class="form-group">
                <label for="exampleInputEmail1">Título</label>
                <?php
                
                echo "<input type='hidden' value='$id' name='id'>";
                
                echo '<input type="text" name="login" value="'.$titulo.'" class="form-control" id="exampleInputEmail1">';
                
                ?>
              </div>
              <div class="form-group">
                <label for="exampleInputPassword1"></label>
                 <?php
                
                echo '
                <div>
                <label for="exampleFormControlTextarea1">Digite no corpo</label>
                <textarea class="form-control" name="corpo" value="'.$corpo.'" id="exampleFormControlTextarea1" rows="3"></textarea>
                </div>';
                
                
                ?>
                
              </div>
             
              <button type="submit" class="btn btn-primary">Alterar</button>
            </form>
        </div>
    </div><!--fim container -->
    
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>

    <!-- Option 2: jQuery, Popper.js, and Bootstrap JS
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
    -->
  </body>
</html>